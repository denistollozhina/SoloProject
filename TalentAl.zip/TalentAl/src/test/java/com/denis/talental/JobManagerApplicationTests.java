package com.denis.talental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
